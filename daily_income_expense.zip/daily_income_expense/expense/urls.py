from django.contrib import admin
from django.urls import path 
from . import views as v

urlpatterns = [
    path('admin/', admin.site.urls),
    path('exp',v.addexpense,name="exp"),
    path('expenselist',v.expense_list),
    path('delete1/<int:id>',v.delete_list),
    path('edit1/<int:id>',v.edit_list),
]
