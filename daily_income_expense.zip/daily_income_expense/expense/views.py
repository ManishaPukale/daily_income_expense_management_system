from django.shortcuts import render,redirect
from .models import ExpenseForm

 
 
 
def addexpense(request):
    if request.method=='POST':
        f=ExpenseForm(request.POST)
        f.save()
        return redirect('/')
    else:
        f=ExpenseForm
        context={'form':f}
        return render(request,'addexpense.html',context)
    
    
    
from .models import Expense


def expense_list(request):
   
    uid=request.session.get('uid')
    eliste=Expense.objects.filter(user=uid)
    z={'x':eliste}
    return render(request,'expenselist.html',z)

def delete_list(request,id):
    x=Expense.objects.get(id=id)
    x.delete()
    return redirect('/') 


def edit_list(request,id):
    m=Expense.objects.get(id=id)
    if request.method=='POST':
        f=ExpenseForm(request.POST,instance=m)
        f.save()
        return redirect('/')
    else:
        f=ExpenseForm(instance=m)
        context={'w':f}
        return render(request,'addexpense.html',context)
    
# def sort_by_expense(request):
#     uid=