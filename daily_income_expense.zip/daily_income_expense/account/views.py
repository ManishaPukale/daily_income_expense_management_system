from django.shortcuts import render,redirect

# Create your views here.

def home(request):
    return render(request,'home.html')


from django.contrib.auth.forms import UserCreationForm


def adduser(request):
    if request.method=='POST':
        f=UserCreationForm(request.POST)
        f.save()
        return redirect('/')
    else:
        f=UserCreationForm
        context={'form':f}
        return render(request,'adduser.html',context)
    
from .models import LoginForm
from django.contrib.auth import authenticate,login,logout

def login_view(request):
    if request.method=='POST':
        uname=request.POST.get('username')
        upassword=request.POST.get('password')
        user=authenticate(request,username=uname,password=upassword)
        if user is not None:
            request.session['uid']=user.id
            login(request,user)
            return redirect('/')
        else:
            f=LoginForm
            context={'form':f}
            return render(request,'login.html',context)
            
    else:
        f=LoginForm
        context={'form':f}
        return render(request,'login.html',context)
    
def logout_view(request):
    logout(request)
    return redirect('/')
    
    


    
    
 
    
        
   
