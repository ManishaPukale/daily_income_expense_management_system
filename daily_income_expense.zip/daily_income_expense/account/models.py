from django.db import models

from django import forms
class LoginForm(forms.Form):   #helper class django model class 
    username=forms.CharField(max_length=30)
    password=forms.CharField(max_length=30,widget=forms.PasswordInput)
    
    
    
